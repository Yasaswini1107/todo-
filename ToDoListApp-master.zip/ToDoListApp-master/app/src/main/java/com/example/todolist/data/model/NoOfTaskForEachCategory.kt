package com.example.todolist.data.model

data class NoOfTaskForEachCategory(
    val category : String,
    val color : String,
    val count : Int,
)
